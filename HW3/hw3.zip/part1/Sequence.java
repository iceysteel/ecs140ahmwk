//Create an abstraction called Sequence which is a dynamic array of Element objects

class Sequence extends Element{

	public Element data;
	public int numElements = 0;
	public Sequence next;

    public Sequence()
    {
	data = null;
	next = null;
    }

    



}
