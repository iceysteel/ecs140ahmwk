//Create an abstraction called Element
//MyChar, MyInteger, and Sequence have Elements

abstract class Element{

	abstract public void Print();
}
